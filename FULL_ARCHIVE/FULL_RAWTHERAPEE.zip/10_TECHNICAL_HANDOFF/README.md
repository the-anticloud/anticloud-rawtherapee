# 10 Technical Handoff

**Project:** RAWTHERAPEE
**Upstream:** https://github.com/RawTherapee/RawTherapee

Content specific to RAWTHERAPEE in category CAMERAS.
